# =====================================================================================================================
# file:         pred_ds_w_R__lab4.R                           
# project:      Predictive Data Science in R 
#               https://www.meetup.com/SF-Bay-ACM/events/240173466/ 
# lab descrip:  Model Building - HoMe EQuity (HMEQ) loan default, cleaned up code, no training material 
# by:           Greg Makowski
# last update:  Sat 9/16/2017
#
#
# Data: HMEQ - HoMe EQuity line of credit.  A line of credit loan, secured by a persons home.
# Using loan applicaiton, person and property data, predict which loans went delinquint (BAD=1) after a year.
#
#   rec_ID   record ID, key field for each loan application for  a line of credittr
#   BAD      After 1 year, loan went in default, (=1, 20%) vs. still being paid (=0) 
#   CLAGE    Credit Line Age, in months (for another credit line)
#   CLNO     Credit Line Number
#   DEBTINC  Debt to Income ratio
#   DELINQ   Number of delinquent credit lines   (0 .. 15)  0 77%,  1 12%,  2 5%,  3 2%, ..
#   DEROG    Number of major derogatory reports
#   JOB      Job, 6 occupation categories
#   LOAN     Requested loan amount
#   MORTDUE  Amount due on existing mortgage
#   NINQ     Number of recent credit inquiries
#   REASON   “DebtCon“ = debt consolidation, “HomeImp“ = home improvement
#   VALUE    Value of current property 
#   YOJ      Years on present job
#
#  https://stackoverflow.com/questions/13685295/sort-a-data-table-fast-by-ascending-descending-order
#  On this data, benchmarks indicate that data.table's order is about ~79x faster than base:::order and 
#  setorder is ~135x faster than base:::order here
#
# =====================================================================================================================


# ---------------------------------------------------------------------------------------------------------------------
eda_targ_by_catg <- function( dt, catg_var, targ_var, global_mean ) {
  
  # ---- 1 way catg analysis, count and perc of categorical frequencies 
  t_c <-  table(dt[, catg_var, with=FALSE] )    # table on a categorical var
  dt_c <- as.data.table(t_c)
  names(dt_c) <- c("catg_name", "catg_cnt")
  dt_c[, catg_perc := round( catg_cnt / sum(catg_cnt), 3) ]
  
  # ---- 2 way (catg by target) frequency analysis
  #  t_2way <-  table( dt[, catg_var, with=FALSE], dt[, targ_var, with=FALSE] )
  t_2way <-  table( dt[, eval(parse(text=catg_var)) ], dt[, eval(parse(text=targ_var))] )
  # R macro, eval(parse(text=SOMEVAR)) will convert any text to code, before execution
  
  dt_2way <- as.data.table( cbind( t_2way[,1], t_2way[,2]) )
  names(dt_2way) <- c( "targ_not", "targ")
  
  # ---- combine the 1 and 2 way
  dt_c <- cbind( dt_c, dt_2way)
  
  # ---- calc lift, order by lift
  dt_c[, perc_targ := round((targ/(catg_cnt)),3) ]
  dt_c[, lift := round(perc_targ/eval(parse(text=global_mean)), 3)]
  setkey(dt_c,lift)   # order by the var lift
  
  return(dt_c)  
}


# ---------------------------------------------------------------------------------------------------------------------
prep_hmeq_d1 <- function( dt ) {
  
  # --------------------------------------------------
  # ---- START PREPROCESSING
  # ---- prep: deal with missing values for floats and categoricals
  eda <- list()                    # create a list variable for Exploratory Data Analysis and metadata
  options(warn=-1)                 # temporarily supress warnings, because some vars are currently character.  The numerics all work fine.
  eda$means <- sapply(dt, mean, na.rm=TRUE)   # save to a data structure  (in production scoring, read from disk the means of training data)
  options(warn=0)
  
  
  # ---- create a list of numeric columns, to apply mean substitution
  num_mean_sub <- c("MORTDUE", "VALUE", "YOJ", "CLAGE", "DEBTINC", "DEROG", "DELINQ", "NINQ", "CLNO")
  # ---- list of flags, where TRUE --> substitute with an integer(mean),  FALSE --> substitute with mean
  num_int_mean <- c( FALSE,     FALSE,   FALSE, FALSE,   FALSE,     TRUE,    TRUE,     TRUE,   TRUE)
  
  for (c in 1:length(num_mean_sub)) {
    
    if (FALSE == num_int_mean[c]) {
      # ---- mean substitute with continuous values
      # code_ln ends up like:    dt[ is.na(DEBTINC), DEBTINC := eda$means['DEBTINC']]
      code_ln <- paste0( "dt[ is.na(", num_mean_sub[c], "), ", num_mean_sub[c], " := eda$means['", num_mean_sub[c], "']]"  )
      eval(parse(text=code_ln))  # execute the macro text
      
    } else {
      # ---- mean substitute with INTEGER values
      # code_ln ends up like:    dt[ is.na(DEBTINC), DEBTINC := as.integer(round(eda$means['DELINQ']))]
      code_ln <- paste0( "dt[ is.na(", num_mean_sub[c], "), ", num_mean_sub[c], " := as.integer(round(eda$means['", num_mean_sub[c], "']))]"  )
      eval(parse(text=code_ln))  # execute the macro text
    } # end else
    
  }
  
  
  # --------------------------------------------------
  # ---- prep: deal with missing values for text categoricals
  # ---- check categorical cols for missing.  Because the missing job is so different in target rate, create a new category.   
  #      For the reason var, missing BAD rate is very similar to the most common category, so substitute with REASON="DebtCon"
  dt[ ""==JOB,    JOB :=    "missing"]   
  dt[ ""==REASON, REASON := "DebtCon"]   
  
  
  # --------------------------------------------------
  # ---- prep:  1-of-N binary encode the categorical cols.  Validate, then drop chars.
  # web search: r one of n encoding
  # ~JOB is the variable to be encoded
  # -1 supresses a new column of 1's, the intercept of the model
  dt_job <- with(dt, data.table(model.matrix(~JOB-1, dt)) )
  dt_res <- with(dt, data.table(model.matrix(~REASON-1, dt)) )
  
  dt <- cbind(dt, dt_job, dt_res)    # column bind, append columns together
  dt[ , JOB := NULL]                 # delete the two encoded character columns
  dt[ , REASON := NULL]
  
  
  # --------------------------------------------------
  # ---- check for long-tail distributions (i.e. skew) and safelog()
  eda$skew <- sapply(dt, skewness)  # create a list of skewness values for each column
  eda$skew                          # look at the results
  # VALUE, DEROG and DELINQ have values over 3.
  
  dt[, value_lg :=  log(VALUE + 1) ]  # +1 to avoid numeric error from log(0).   Sometimes also need log(abs(var)+1) & may want to put sign back on after
  dt[, derog_lg :=  log(DEROG + 1) ]
  dt[, delinq_lg := log(DELINQ + 1)]
  eda$skew <- sapply(dt, skewness)  # check the reduced skewness
  
  dt[, derog_lg :=  log(derog_lg + 1)]   # reduced skew from 5.7 to 3.2.  Want to reduce below 3.
  eda$skew <- sapply(dt, skewness)  # reduced to 2.7.  Good enough
  
  # ---- delete the replaced variables
  dt[, VALUE :=  NULL]  
  dt[, DEROG :=  NULL]  
  dt[, DELINQ := NULL]  
  
  
  # --------------------------------------------------
  # ---- rescale input vars to a 0..1 range
  eda$min <- sapply(dt, min) 
  eda$max <- sapply(dt, max) 
  
  for (c in 3:ncol(dt)) {   # start at 3, skipping the key and the target columns.  Don't change those.
    # code_ln example:  dt[, LOAN := (LOAN - eda$min[c])/(eda$max[c] - eda$min[c]) ]
    code_ln <- paste0( "dt[, ", names(dt)[c], " := (", names(dt)[c], " - eda$min[c])/(eda$max[c] - eda$min[c]) ]")
    eval(parse(text=code_ln))
  }
  
  return(dt)
  
} # end prep_hmeq_d1()


# =====================================================================================================================
# ==== MAIN ====

# ---- Load library program into RAM. List of all libraries used at any time in this training.
library(e1071)          # skewness(), wrapper for C++ libsvm with svm() and more
library(gmodels)        # CrossTable(), like SAS PROC FREQ  
library(Hmisc)          # for Exploratory Data Analysis.  describe(). cut2() for equal frequency binning
library(data.table)     # data.table(), fread()  are VASTLY better than data.frames for data storage & manipulation, fread()

# ---- loaded later, but listed here to be sure they are installed
library(doMC)           # Mac: foreach parallel for loop processing & other, from Revolution Analytics
library(doParallel)     # Windows: foreach parallel processing instead of doMC() for Mac
library(caret)          # Classification And REgression Training - wrapper over many predictive models
library(rpart)          # recursive partitioning, CART decision tree predictive algorithm
library(partykit)       # plot decision trees, other tree infrastruture, pruning of nodes
library(pROC)           # tools for calc, vis or comparing receiver operating characteristic (ROC curves)
library(nnet)           # basic neural network library (not deep learning)


# --------------------------------------------------
# ---- define input/output parameter list
param_io <- list()            # create a list variable
param_io$input_dir <-         "/Users/gregmakowski/Desktop/predictive_ds_in_R/"
setwd( param_io$input_dir )   # set the working directory
param_io$input_data_file <-   paste0(param_io$input_dir, "hmeq.csv")
param_io$data_ver_stub <-     paste0(param_io$input_dir, "hmeq")

log_level <<- 3          # 0 = no output.    3 = for development, more detail


# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- Fast Read the data into a data table (from data.table library, reads million record tables in few sec)
dt <- fread(param_io$input_data_file)    # creats a data table  (much better than a data.frame.  Data Table is new in last few years)


# ----------------------------------------------------------------------------------------------------------
param_prep <- list()

# ---- set the parameters for EDA and preprocessing on data version d1
param_prep$target <-             "BAD"
param_prep$targ_is_catg <-       TRUE
param_prep$key <-                "rec_ID"
param_prep$data_ver <-           1         # first sprint, first data version
param_prep$target_global_mean <- table(dt$BAD)[2] / nrow(dt)   # assign the global target to a list element


# -----------------------------------------------------------------------
# ---- EXPLORATORY DATA ANALYSIS (EDA)
depend_by_job <- eda_targ_by_catg( dt, "JOB", "BAD", param_prep$target_global_mean )  
# LESSON LEARNED --> treat the blank JOB as its own category, because the lift and avg target rate are so different

# ---- now call this for other categorical vars
#      while this has an ordered value, it is still helpful to look at this for EDA
depend_by_delinq <- eda_targ_by_catg( dt, "DELINQ", "BAD", param_prep$target_global_mean )  

depend_by_reason <- eda_targ_by_catg( dt, "REASON", "BAD", param_prep$target_global_mean )  
# missing has same perc_targ as the most frequent category, DebtCon - so group them because of similarity


# -----------------------------------------------------------------------
# ---- PREPROCESSING (PREP).  SIMPLE, FOR DATA VERSION D1

if (3 <= log_level) {
  sapply(dt, mean, na.rm=TRUE) 
}
dt <- prep_hmeq_d1( dt )        # ==== PREPROCESSING FUNCTION

if (3 <= log_level) {
  sapply(dt, mean, na.rm=TRUE) 
}




# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------
# ---- MODEL BUILDING

# ------------------------------------------------------------
# ---- train in parallel using Multi Core (for Unix/Mac) or doParallel (for Win)
# To enable parallel processing, you first need to load an adaptor for the foreach package 
# (doMC, doMPI, doParallel, doRedis, doRNG or doSNOW)), register the backend, and set parallel=TRUE.
library(doMC)            # Unix/Mac: parallel for loop processing & other, from Revolution Analytics
registerDoMC(cores = 4)  # for MacPro.  Watch CPU load with "activity monitor"

#### library(doParallel) # Windows: parallel processing instead of doMC() for Mac


# ------------------------------------------------------------
# split into training vs val, 75% sample, use caret function createDataPartition()
library(caret)
set.seed(42)     # set seed so later runs return the same result, results are repeatable 

dt$BAD <- factor(dt$BAD,  levels = c(0, 1))
input_vars <- names(dt[, 2:ncol(dt)])  # skip the rec_ID var, keep just the target and inputs

trn_row_num <- createDataPartition(dt$BAD,  p = 0.75,  list = FALSE)
head(trn_row_num)   # one column data.frame, col named Resample1 with row index of training records
dim(trn_row_num)    # 4471 1
d1_trn <- dt[ trn_row_num, input_vars, with=FALSE]
d1_val <- dt[-trn_row_num, input_vars, with=FALSE]
dim(d1_val)   # 1489 21


# ====================================================================================================
# ====================================================================================================
# --------------------------------------------------
# ---- write out the data sets to save data ver.
checkpoint_write_or_read = "w"

if (checkpoint_write_or_read == "w") {
  fwrite(dt, file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
  saveRDS( d1_trn, "models/d1_trn.rds")  # save the data (with this trn/val split) for future use
  saveRDS( d1_val, "models/d1_val.rds")  # save the data (with this trn/val split) for future use
  
} else {
  # ---- just read this in if I have to start at a mid-point checkpoint
  dt <- fread( file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
  d1_trn <- readRDS( "models/d1_trn.rds")  # save the data (with this trn/val split) for future use
  d1_val <- readRDS( "models/d1_val.rds")  # save the data (with this trn/val split) for future use
}


# ====================================================================================================
# ====================================================================================================


# ------------------------------------------------------------
# ---- PLAN TO MANAGE COMPLEXITY (may want consistency in proj over team members, "vacation insurance")
# ---- Stay organized, develop some naming struture good enought to track 30-300 models
#      * data versions (d1, d2,... later sprints)
#      * training vs. test data
#      * algorithm used to train,  model version (m1, m2, m3, ..)
#      * scored training/test data data, with model using alg X and m2
#      * design principal:  slowest changes to the farthest left of the name
#  
#   d1_trn          data version 1, training input data
#   d1_val          data ver 1, test or valiation data
#   d1_hld          data ver 1, on another holdout data subset (if used)
#   d1_tree_m1      trained model, data ver = 1, alg = tree, tree model ver = 1
#   d1_treec_m3     (similar to above, the tree was trained with <c>aret, if we want to track)
#   d1_trn_tree_m1  apply tree m1 to score the d1 training data
#   d1_val_tree_m1  apply tree m1 to score the d1 validation data
#
#   DATA NAMES 
#   d<data_ver>_<trn|val|hld>  
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>    (if scored with a model)
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_class  produce a categorical forecast
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_prob   produce a probability forecast
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_roc    ROC score
#
#   MODEL NAMES
#   d<data_ver>_<alg>_<alg ver>
#   d<data_ver>_<alg>_<alg ver>_plot   (or other things with the model)
#   

# ------------------------------------------------------------
# ---- train some predictive models
library(rpart)          # recursive partitioning, CART decision tree predictive algorithm


d1_tree_m1 <- rpart(BAD ~ .,
                    data =    d1_trn,
                    control = rpart.control(maxdepth = 2))  # max of 2 splits, easy to plot
d1_tree_m1

# ---- try the partykit package for plotting trees
library(partykit)
d1_tree_m1_plot <- as.party(d1_tree_m1)
plot(d1_tree_m1_plot)                # nice looking plot

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
jpeg(filename= paste0(param_io$input_dir,"models/d1_tree_m1_plot.jpeg"), width = 1800, height = 900)   
plot(d1_tree_m1_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ------------------------------------------------------------
# ---- generate a larger tree, not limited to 2 levels.  
# use "One SE" rule
# estimate standard error for each tree size, then
# choose the simplest tree within one standard error of the absolute best tree size
d1_tree_m2 <- rpart(BAD ~ .,
                    data =    d1_trn,
                    control = rpart.control(minbucket = 20))

saveRDS( d1_tree_m2, "models/d1_tree_m2.rds")  # save the model for future scoring

d1_tree_m2_plot <- as.party(d1_tree_m2)
plot(d1_tree_m2_plot)                # nice looking plot

d1_tree_m2   # look at the text tree

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
#      this version is much higher resolution, and more readable
jpeg(filename= paste0(param_io$input_dir,"models/d1_tree_m2_plot.jpeg"), width = 1800, height = 900)   
plot(d1_tree_m2_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ------------------------------------------------------------
# ---- tree scoring of test data
d1_val_tree_m2 <- predict(d1_tree_m2, 
                          newdata = d1_val,
                          type =    "class")    # class = category,  prob = probability

confusionMatrix(data =      d1_val_tree_m2, 
                reference = d1_val$BAD)

d1_val_tree_m2_conf <- confusionMatrix(data =      d1_val_tree_m2, 
                                       reference = d1_val$BAD)

str( d1_val_tree_m2_conf)             # get the data structure for what was printed to the console
d1_val_tree_m2_conf$overall
d1_val_tree_m2_conf$overall$Accuracy  # no, not a named list  (KNOWN ERROR, to show a point)
d1_val_tree_m2_conf$overall[1]        # works to get the number for accuracy (save what you track/model)


# ------------------------------------------------------------
# ---- create ROC curve 
d1_val_tree_m2_prob <- predict(d1_tree_m2, 
                               newdata = d1_val)

head(d1_val_tree_m2_prob, 3)
names(d1_val_tree_m2_prob)

library(pROC)

#     The roc function assumes the *second* level is the one of
#     interest, so we use the 'levels' argument to change the order.
d1_val_tree_m2_roc <- roc(response = d1_val$BAD,
                          predictor = d1_val_tree_m2_prob[, 2], 
                          levels =    rev(levels(d1_val$BAD)))

#     Get the area under the ROC curve
auc(d1_val_tree_m2_roc)
# Area under the curve: 0.8907

plot(d1_val_tree_m2_roc)


# ------------------------------------------------------------
# ---- start using caret to train models.  
# save the trainControl settings to cv_ctrl, used later in the train() function
cv_ctrl <- trainControl(method = "repeatedcv",  # 10 fold cross validation
                        repeats = 5)            # repeated 5 times

# ---- I added "c" to the end of the tree in the model name
d1_treec_m3 <- train(BAD ~ .,
                     data =       d1_trn,
                     control = rpart.control(minbucket = 20),
                     method =     "rpart",       # train a CART tree model, as before
                     tuneLength = 9,             # caret function to eval many models
                     trControl =  cv_ctrl)       # cross validation 5 times, used above params here

saveRDS( d1_treec_m3, "models/d1_treec_m3.rds")  # save the model for future scoring

d1_treec_m3  # shows 9 values of cp tested 
# cp is the rpart complexity parameter to stop growing forward
# best was cp = 0.006726457.   (default is 0.01)


str(d1_treec_m3)  # a very long list

# ---- try the partykit package for plotting trees
library(partykit)
d1_treec_m3$finalModel  # output the text tree
d1_treec_m3_plot <- as.party(d1_treec_m3$finalModel)
plot(d1_treec_m3_plot)                # nice looking plot

# note, JOBmissing came into the tree

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
#      this version is much higher resolution, and more readable
jpeg(filename= paste0(param_io$input_dir,"models/d1_treec_m3_plot.jpeg"), width = 1800, height = 900)   
plot(d1_treec_m3_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ---------------------------
# ---- check the validation accuracy
d1_val_treec_m3_prob <- predict(d1_treec_m3$finalModel, 
                                newdata = d1_val)

d1_val_treec_m3_roc <- roc(response =  d1_val$BAD,
                           predictor = d1_val_treec_m3_prob[, 2], 
                           levels =    rev(levels(d1_val$BAD)))
auc(d1_val_treec_m3_roc)  # 0.8907


# ---------------------------
# ---- sensitivity analysis, to describe the primary driving variables of the model
d1_val <- readRDS( "models/d1_val.rds")  # save the data (with this trn/val split) for future use
source(file = paste0( param_io$input_dir, "segmented_sensitivity_analysis.R")) 

# ---- rank the most important variables to the model 
predict_func <-     "predict"                # may change function to custom for ensemble of models
model_in <-         d1_treec_m3$finalModel
dt_in <-            d1_val                   # validation data or subset (keep to 10k or less)
input_var_list <-   names(d1_val)[2:ncol(d1_val)]   # skip the first var, the target
targ_var_name <-    "BAD_forecast"
forc_var_pos <-     2                        # forecast variable column position in scored output matrix
sens_mult_factor <- 1.05                     # optional parameter, defaults to 1.05

d1_treec_m3_descrip <- segm_sens_anal( predict_func, model_in, dt_in, input_var_list, 
                                       targ_var_name, forc_var_pos, sens_mult_factor ) 
sapply(d1_treec_m3_descrip, mean)


model_in <-         d1_tree_m1
d1_tree_m1_descrip <- segm_sens_anal( predict_func, model_in, dt_in, input_var_list, 
                                       targ_var_name, forc_var_pos, sens_mult_factor ) 

sapply(d1_tree_m1_descrip, mean)

# ------------------------------------------------------------
# ---- neural net
library(nnet)           # basic neural network library (not deep learning)

# use the same cv_ctrl specified before
cv_ctrl <- trainControl(method = "repeatedcv",  # 10 fold cross validation
                        repeats = 5)            # repeated 5 times

# ---- training the many neural nets with all this cross validation & retraining takes longer
#      about 13 minutes
#      track the time and go get your coffee
start_time_n <- proc.time()

d1_nnetc_m1 <-  train(BAD ~ .,
                      data =       d1_trn,
                      method =     "nnet",        # train a neural net model
                      tuneLength = 9,             # caret function to eval many models
                      trControl =  cv_ctrl)       # cross validation 5 times, used above params here

end_time_n <- proc.time()
duration_n <- end_time_n - start_time_n
duration_n

length(duration_n)
names(duration_n)
duration_n[3]       # 807.683
duration_n[3]/60    # 13 min

saveRDS( d1_nnetc_m1, "models/d1_nnetc_m1.rds")  # save the model for future scoring


#  weights:  358
#  initial  value 6223.589862 
#  iter  10 value 2209.654782
#  iter  20 value 2112.410853
#  iter  30 value 2062.964599
#  iter  40 value 2015.094375
#  iter  50 value 1851.424283
#  iter  60 value 1716.623851
#  iter  70 value 1638.157046
#  iter  80 value 1579.116674
#  iter  90 value 1563.965881
#  iter 100 value 1550.663330
#  final  value 1550.663330 
#  stopped after 100 iterations


d1_nnetc_m1$finalModel
# ---- results
#      a 22-15-1 network with 361 weights
#      inputs: LOAN MORTDUE VALUE YOJ DEROG DELINQ CLAGE NINQ CLNO DEBTINC JOBMgr JOBmissing JOBOffice JOBOther JOBProfExe JOBSales JOBSelf REASONDebtCon REASONHomeImp value_lg derog_lg delinq_lg 
#      output(s): .outcome 
#      options were - entropy fitting  decay=0.005179475


# ---- now I will take those settings and change one parameter
#      I want to test connecting the input layer to the output, skipping the hidden
#      This solves the linear part of the problem quicker with the skip layer
#      and leaves the hidden nodes to solve the remaining challenges
d1_nnet_m2_time_start <- proc.time()
d1_nnet_m2 <- nnet(d1_trn[, LOAN:delinq_lg ],
                   as.integer(d1_trn$BAD)-1,  # not the formula, but inputs & target
                   size =    17,          # number hidden nodes
                   entropy = TRUE,        # caret found setting 1
                   decay =   0.005179475, # caret found setting 2
                   skip =    TRUE         # new change, parameter to test
                  )
d1_nnet_m2_time_end <- proc.time()
d1_nnet_m2_time_dur <- d1_nnet_m2_time_end - d1_nnet_m2_time_start
d1_nnet_m2_time_dur[3]/60  # elapsed 2% of a minute

saveRDS( d1_nnet_m2, "models/d1_nnet_m2.rds")  # save the model for future scoring

# final val 1129  
1173 - 1129   # 44 better


# ------------------------------------
# ---- now increase the iterations significantly 
d1_nnet_m3 <- nnet(d1_trn[, LOAN:delinq_lg ],
                   as.integer(d1_trn$BAD)-1,  # not the formula, but inputs & target
                   size =    17,          # number hidden nodes
                   entropy = TRUE,        # caret found setting 1
                   decay =   0.005179475, # caret found setting 2
                   skip =    TRUE,
                   maxit =   1000         # new change, parameter to test
)

# final val 781, after 860 iterations  (leveled off to the same value at 680, don't expect more improvement from this param)
1173 - 781   # 392 better, after using caret with my own improvements

saveRDS( d1_nnet_m3, "models/d1_nnet_m3.rds")  # save the model for future scoring


# ---------------------------
# ---- sensitivity analysis, to describe the primary driving variables of the model
d1_val <- readRDS( "models/d1_val.rds")  # save the data (with this trn/val split) for future use
source(file = paste0( param_io$input_dir, "segmented_sensitivity_analysis.R")) 

# ---- rank the most important variables to the model 
predict_func <-     "predict"                # may change function to custom for ensemble of models
model_in <-         d1_nnet_m3
dt_in <-            d1_val                   # validation data or subset (keep to 10k or less)
input_var_list <-   names(d1_val)[2:ncol(d1_val)]   # skip the first var, the target
targ_var_name <-    "BAD_forecast"
forc_var_pos <-     1                        # forecast variable column position in scored output matrix
sens_mult_factor <- 1.05                     # optional parameter, defaults to 1.05

d1_nnet_m3_descrip <- segm_sens_anal( predict_func, model_in, dt_in, input_var_list, 
                                       targ_var_name, forc_var_pos, sens_mult_factor ) 
sapply(d1_nnet_m3_descrip, mean)




# ------------------------------------------------------------
# ---- XGboost
library(xgboost)

# ---- caret and other libraries expected a binary target to be of type factor
#      a factor encodes numeric or character category values internally as 1, 2, 3..

# ---- xgboost works with specific data structures for its library
#      it expects all integer or numeric, no factors
#      Below are a few lines that explore to figure out, and then transform to the desired label
table(d1_trn$BAD)
table( as.integer(d1_trn$BAD) )
table( as.integer(d1_trn$BAD) -1 )

d1_trn_xgb_targ <- as.integer(d1_trn$BAD) - 1
d1_val_xgb_targ <- as.integer(d1_val$BAD) - 1


# ---- for xgboost, for the input data, we need a version without the key field or target
#      data tables by default do all in-place changes (by reference).  Need to be explicit to make a copy
d1_trn_xgb_inp <- copy(d1_trn)  # so we can modify x and not change train_data
d1_trn_xgb_inp[ , rec_ID := NULL]   # delete the key
d1_trn_xgb_inp[ , BAD := NULL]      # delete the target
d1_trn_xgb_inp <- as.matrix(d1_trn_xgb_inp)  # convert to a matrix

d1_val_xgb_inp <- copy(d1_val)  # so we can modify x and not change train_data
d1_val_xgb_inp[ , rec_ID := NULL]   # delete the key
d1_val_xgb_inp[ , BAD := NULL]      # delete the target
d1_val_xgb_inp <- as.matrix(d1_val_xgb_inp)  # convert to a matrix


# ---- convert to the optimized for xgboost data structure, DMatrix
d1_trn_xgb <- xgb.DMatrix(data =  d1_trn_xgb_inp,
                          label = d1_trn_xgb_targ)

d1_val_xgb <- xgb.DMatrix(data =  d1_val_xgb_inp,
                          label = d1_val_xgb_targ)


# ---- now train
d1_xgb_m1 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2,           # depth per tree
                     eta =       1,           # decay weight (high here because short nrounds)
                     nrounds =   2,           # train 2 small CART trees
                     objective = "binary:logistic")
#  [1]	train-error:0.181391   # results for tree 1
#  [2]	train-error:0.138671   # results for tree 1 + tree 2


# ---- now score or apply the model to forecast
d1_trn_xgb_m1 <- predict(d1_xgb_m1, d1_trn_xgb)
d1_val_xgb_m1 <- predict(d1_xgb_m1, d1_val_xgb)



# ---- now try (a more normal), longer sequence of 200
d1_xgb_m2 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2, 
                     eta =       0.25,        # smaller decay wgt
                     nrounds =   200,         # 200 small trees
                     objective = "binary:logistic",
                     subsample = 0.5 )        # random samp 50% train for each tree, helps with robustness
#  :
#  [195]	train-error:0.065086 
#  [196]	train-error:0.065310 
#  [197]	train-error:0.065310 
#  [198]	train-error:0.065310 
#  [199]	train-error:0.065310 
#  [200]	train-error:0.064191 

#  error dropped from 0.138 to 0.064,  much better

# ---- apply model
d1_trn_xgb_m2 <- predict(d1_xgb_m2, d1_trn_xgb)
d1_val_xgb_m2 <- predict(d1_xgb_m2, d1_val_xgb)



# ---- now try (a more normal), longer sequence of 1000!
d1_xgb_m3 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2, 
                     eta =       0.25,        # smaller decay wgt
                     nrounds =   1000,        # 1,000 small trees
                     objective = "binary:logistic",
                     subsample = 0.5 )        # random samp 50% train for each tree, helps with robustness
#  :
#  [1000]	train-error:0.012972 

#  error continues to drop!!  .14 --> 0.06 --> .01 !!

saveRDS( d1_xgb_m3, "models/d1_xgb_m3.rds")  # save the model for future scoring


# ---- apply model
d1_trn_xgb_m3 <- predict(d1_xgb_m3, d1_trn_xgb)
d1_val_xgb_m3 <- predict(d1_xgb_m3, d1_val_xgb)



# ---------------------------
# ---- sensitivity analysis, to describe the primary driving variables of the model
d1_val <- readRDS( "models/d1_val.rds")  # save the data (with this trn/val split) for future use
source(file = paste0( param_io$input_dir, "segmented_sensitivity_analysis.R")) 

# ---- rank the most important variables to the model 
predict_func <-     "predict"                # may change function to custom for ensemble of models
model_in <-         d1_xgb_m3
dt_in <-            d1_val_xgb               # validation data or subset (keep to 10k or less)
input_var_list <-   names(d1_val)[2:ncol(d1_val)]   # skip the first var, the target
targ_var_name <-    "BAD_forecast"
forc_var_pos <-     1                        # forecast variable column position in scored output matrix
sens_mult_factor <- 1.05                     # optional parameter, defaults to 1.05

#d1_xgb_m3_descrip <- segm_sens_anal( predict_func, model_in, dt_in, input_var_list, 
#                                      targ_var_name, forc_var_pos, sens_mult_factor ) 
#
# Error in mat_score_default[, forc_var_pos] :    incorrect number of dimensions


# =====================================================================================================================

