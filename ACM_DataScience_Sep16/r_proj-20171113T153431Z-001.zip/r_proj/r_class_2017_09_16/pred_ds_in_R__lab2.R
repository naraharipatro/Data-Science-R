# =====================================================================================================================
# file:         pred_ds_w_R__lab2.R
# project:      Predictive Data Science in R 
#               https://www.meetup.com/SF-Bay-ACM/events/240173466/ 
# lab descrip:  load and review HoMe EQuity (HMEQ) loan default
# by:           Greg Makowski
# last update:  Sat 9/16/2017
#
#
# Data: HMEQ - HoMe EQuity line of credit.  A line of credit loan, secured by a persons home.
# Using loan applicaiton, person and property data, predict which loans went delinquint (BAD=1) after a year.
#
#   rec_ID   record ID, key field for each loan application for  a line of credittr
#   BAD      After 1 year, loan went in default, (=1, 20%) vs. still being paid (=0) 
#   CLAGE    Credit Line Age, in months (for another credit line)
#   CLNO     Credit Line Number
#   DEBTINC  Debt to Income ratio
#   DELINQ   Number of delinquent credit lines
#   DEROG    Number of major derogatory reports
#   JOB      Job, 6 occupation categories
#   LOAN     Requested loan amount
#   MORTDUE  Amount due on existing mortgage
#   NINQ     Number of recent credit inquiries
#   REASON   “DebtCon“ = debt consolidation, “HomeImp“ = home improvement
#   VALUE    Value of current property 
#   YOJ      Years on present job
#
# =====================================================================================================================

# ---- one time install packages/libraries on disk (if you haven't already)
install.packages("e1071")
install.packages("gmodels")
install.packages("Hmisc")
install.packages("data.table")
install.packages("doMC")
install.packages("doParallel")
install.packages("caret")
install.packages("rpart")
install.packages("partykit")
install.packages("pROC")
install.packages("nnet")


# --------------------------------------------------
# ---- Load library program into RAM. List of all libraries used at any time in this training.
library(e1071)          # skewness(), wrapper for C++ libsvm with svm() and more
library(gmodels)        # CrossTable(), like SAS PROC FREQ  
library(Hmisc)          # for Exploratory Data Analysis.  describe(). cut2() for equal frequency binning
library(data.table)     # data.table(), fread()  are VASTLY better than data.frames for data storage & manipulation, fread()

# ---- loaded later, but listed here to be sure they are installed
# library(doMC)           # Mac: foreach parallel for loop processing & other, from Revolution Analytics
# library(doParallel)     # Windows: foreach parallel processing instead of doMC() for Mac
# library(caret)          # Classification And REgression Training - wrapper over many predictive models
# library(rpart)          # recursive partitioning, CART decision tree predictive algorithm
# library(partykit)       # plot decision trees, other tree infrastruture, pruning of nodes
# library(pROC)           # tools for calc, vis or comparing receiver operating characteristic (ROC curves)
# library(nnet)           # basic neural network library (not deep learning)


# --------------------------------------------------
# ---- define input/output parameter list
param_io <- list()            # create a list variable
param_io$input_dir <-         "C:/Users/Greg Makowski/Documents/r_proj/r_class_2017_09_16/"
setwd( param_io$input_dir )   # set the working directory
param_io$input_data_file <-   paste0(param_io$input_dir, "hmeq.csv")
param_io$data_ver_stub <-     paste0(param_io$input_dir, "hmeq")

# ---- manipulate an example data structure
param_io                      # show the full list
length(param_io)              # find the length, use for list iteration
param_io$input_data_file      # access by list element name
param_io[3]                   # access by subscript
str(param_io)                 # get the structure of an object
print(param_io)               # print an object
class(param_io)               # find the type of an object


# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- Fast Read the data into a data table (from data.table library, reads million record tables in few sec)
dt <- fread(param_io$input_data_file)    # creates a data table  (much better than a data.frame.  Data Table is new in last few years)

# ---- now you try str(), class(),

ls()                          # list objects in memory. See also RStudio top right, Environment

? fread()   # to get read the help or documentation
# web search "r data.table fread tutorial example"   if you want more

sort( sapply(ls(),
             function(x) {object.size(get(x))} 
) )              # give a sorted list of objects in memory
# function(x)   is a generic function defined and used in the scope of another function

# in R, avoid for() loop on over 1k elements, use the vector apply() family
#   search "r tutorial apply" or go to   https://www.datacamp.com/community/tutorials/r-tutorial-apply-family
# sapply - apply vect function, read in list or vect, output vector
# lapply - apply vect function, read in list or vect, output list
#  apply - apply vect function, read in matrix, operate on "margin", i.e. dimension 1 or 2
# tapply - apply vect function, for data.frames


# ---- try the help tab on right, or ? ls() or web search for "r ls pdf"


# --------------------------------------------------
# ---- explore looking at the data set
# ---- find out about the file
dim(dt)     # 5960  14    get the dimensions, the number of rows and columns
dim(dt)[1]  # 5960
dim(dt)[2]  # 14
nrow(dt)    # 5960
ncol(dt)    # 14     # used in for loops

names(dt) # get the field names

str(dt)   # structure of the data.  For each field, list field name, type and example values

summary(dt)  # aggregate measures per field:  min, mean, max, NA' frequency
# note, DEBTINC has 1267 missing, 4693 not-missing.  May want to skip 

describe(dt) # info like summary(), but a more detailed.  Frequency of catgorical fields.  Part of Hmisc library.

sum(is.na(dt))              # how many missing values?  4740 (out of 5960 records!)

dt$na_cnt <- apply(dt, 1, function(x) sum(is.na(x)))  
sum(dt$na_cnt)    
sum(dt$na_cnt) / nrow(dt)   # 80% of the rows have at least one missing value
dt[, na_cnt:= NULL]         # delete the temporary col

table(dt$JOB)

# ---- EDA, how inputs relate to the target, BAD
table(dt$JOB, dt$BAD)

# ---- web search:  r table percent    (want more details in output.  Cell%, row%, col%)
library(gmodels)
CrossTable(dt$JOB, dt$BAD)    # like SAS proc FREQ 


# --------------------------------------------------
# ---- DESIGN TO SCALE WITH COMPLEXITY 
#          HUGE NUMBER OF INPUT VARS, OR DYNAMICALLY CHANGING
#      Want to be robust to changes upstream in the preprocessing
#
#      work with "sets" of fields, select by naming convention or other metadata
#      The selection is robust to adding or dropping fields upstream
#      Also makes it easy to "drop" or "keep" sets of variables (set intersection)
#      This reduces "brittleness" of the current code

var_list <- names(dt)    # extract a list of all the possible input vars
var_list                 # show what was generated. 
var_list[3]

d_any_vars <-   var_list[ grepl("D",  var_list) ]     # match the var names with "D anywhere"
d_any_vars

d_start_vars <- var_list[ grepl("^D",  var_list) ]    # match the var names with "D in the start"
d_start_vars

JOB_vars <-     var_list[ grepl("JOB", var_list) ]    # match the var names with "JOB"
ts_vars <-      var_list[ grepl("timeseries_m[1234567]_", var_list) ]   # pull all of a time series
# yes, I know we don't have any time series vars.  We can be robust, and not worry

target_var <-   "LOAN"


param_model <- list()
param_model$input_vars <- sort( c( target_var, d_start_vars, ts_vars, "MORTDUE", "CLNO" ) )
param_model$input_vars




# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- START EDA & PREPROCESSING


# =====================================================================================================================

