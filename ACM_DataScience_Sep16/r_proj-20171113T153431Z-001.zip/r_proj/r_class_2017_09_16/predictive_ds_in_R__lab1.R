# ===============================================================================
# file:         predictive_ds_w_R__lab1.R
# project:      review training material on data.tables
# by:           Greg Makowski
# -------------------------------------------------------------------------------
require(data.table)

# DT[ i, j, k ]    # there are three data frame slots, and they have these names
# “Take DT, subset rows using i, then calculate j grouped by by”
#     i selects rows or records
#        j selects columns / vars / fields
#           k is used for dealing groups of rows as a unit
#
#   R:   i      j       k
# SQL: where  select  group


# -------------------------------------------------------------------------------
# ---- datatable - vignette.pdf ---------------
DT = data.table( x = c("b","b","b","a","a"), 
                 v = rnorm(5) )

DT
DT[x=="b", ]    # query the records with x containing b
setkey(DT, x)
DT["b", ]       # after setkey, assumes to compare against the key, returns 3 rows
DT["b", mult="first"]  # like sas by.group processing, first of group
DT["b", mult="last"]   # last record of the group

CARS = data.table(cars)
head(CARS)
tables()        # list the tables and any keys


# j expressions
DT[,sum(v)]

DT[,sum(v), by=x]
DT[, .(sumbyx=sum(v)), by=x]
DT[, .(sumbyx=sum(v), avgbyx=mean(v) ), by=x]
DT[, .(sumbyx=sum(v), avgbyx=mean(v), sdbyx=sd(v) ), by=x]

DT[,  one:=1]    # I am adding this because there appears to be no count(*) function to count
                 # records in the by-group.  But I can sum(one) instead.
DT[, .(sumbyx=sum(v), avgbyx=mean(v), sdbyx=sd(v), cntbyx=sum(one) ), by=x]


# field names contained in variables
names(DT)  # "x"  "v"  "one"
mycol <- "x"
DT[ , mycol, with=FALSE]  # returns a data frame, select var named in mycol

new_var <- "nxt"
mycol <-   "v"
DT[ , mycol, with=FALSE]     # returns v, as expected
DT[ , mycol/10, with=FALSE]           # ERROR in mycol/10 : non-numeric argument to binary operator
DT[ , new_var:=mycol/10, with=FALSE]  # ERROR in mycol/10 : non-numeric argument to binary operator

DT[[mycol]]               # returns a list instead of a vector

code_ln <- paste0(mycol, "/10")
code_ln                               # "v/10"
DT[ , eval(parse(text=code_ln))]      # This works with R macros


# -------------------------------------------------------------------------------
# not just variables containing field names, but expressions of field names
q = quote(x)              # save the data.table var name "x", in a variable q.  "x" has vals like "a", "b"
DT[, eval(q)]             # same result as as dt[[mycol]]

q = quote(list(x))
DT[, eval(q)]             # returns a data table (more commonly used result)

q = quote(list(x, sd(v), mean(v*one)))
DT[, eval(q)]             # returns a data table (more commonly used result)

q = quote(list(v2=v/10))
DT[, eval(q)]             # returns the calculation, but does not edit the table DT
DT[, v2:=eval(q)]         # UPDATES the data table with the new var v2

new_var <- "v3"
DT[, eval(new_var):=eval(q) ]  # UPDATES DT with the new variable named "v3"

dt_sum <- summary(DT)


# ---- try a list containing a subset of vars
tmp <- c("v", "one")
subs <- quote( tmp )
DT[ , eval(subs), with=FALSE]


# ---- try dropping a variable that is in a var name
to_drop <- "one"
DT[ , eval(to_drop):=NULL, with=FALSE];   DT



# -------------------------------------------------------------------------------
# ---- example of macros
DT = as.data.table(iris)
whatToRun = quote( .(AvgWidth = mean(Sepal.Width),
                     MaxLength = max(Sepal.Length)) )
DT[, eval(whatToRun), by=Species]   # execute macro with the eval() 
DT[, eval(whatToRun), by=.(FirstLetter=substring(Species,1,1))]  # diff examples
DT[, eval(whatToRun), by=.(Petal.Width=round(Petal.Width,0))]


# ---- an example like a SQL query
# select mean(Sepal.Length) as avg_SL,
#        mean(Sepal.Width) as  avg_SW
# from   DT
# where  (5.0 < Sepal.Length)
# group by Species
DT[ 5.0 < Sepal.Length, .(avg_SL = mean(Sepal.Length), 
                          avg_SW = mean(Sepal.Width)), by= Species]
# DT[ i, j, k ]    # there are three data frame slots, and they have these names
# DT[ where, seelct, group by]         
         

# -------------------------------------------------------------------------------
# datatable-faq.pdf

# ---- JOIN related examples
# X[Y]     # uses Y's key, looking up X's rows
# X[Y,j]   # selectes the j list of fields to keep in the result - from EITHER table

# ---- see page 6 for details on the J clause, .EACHI
# it groups the calculations over each unique category combination listed in the i expression

# ---- Subset of Data or SD expressions, page 7
#      So to sum up all your columns it’s just:    (.SD creates a list of all vars not in by=__ clause)
DT = as.data.table(iris)
DT[ , lapply(.SD,sum), by=Species]   # l apply is list-apply.  Apply the function sum to all in the list
DT[,  one:=1] 
DT[ , lapply(.SD,sum), by=Species]   # validate after adding one more column (works)
# .SDcols allows you to select a subset of columns


# q) How to create a new data.table, with the field structure of an existing table?
NEW_DT = DT[0]


# p13:  2.16 I’ve heard that data.table syntax is analogous to SQL. Yes :
#  i <==> where
#  j <==> select
#  := <==> update
#  by <==> group by
#  i <==> order by (in compound syntax)
#  i <==> having (in compound syntax)
#  nomatch=NA <==> outer join
#  nomatch=0 <==> inner join
#  mult="first"|"last" <==> N/A because SQL is inherently unordered
#  roll=TRUE <==> N/A because SQL is inherently unordered
#  The general form is :
#    DT[where,select|update,group by][order by][...]  ...  [...]


# -------------------------------------------------------------------------------
# Using .SDcols for column subset and by=id for row mean and row stard deviation
# http://stackoverflow.com/questions/25535573/how-to-create-mean-and-s-d-columns-in-data-table
test <- data.frame('id'=c(1,2,3,4,5),
                   'A'=seq(2,9,length=5),
                   'B'=seq(3,9,length=5),
                   'C'=seq(4,9,length=5),
                   'D'=seq(5,9,length=5))

test <- as.data.table(test)

test[,`:=`(mean_test = rowMeans(.SD), 
           sd_test =   sd(.SD)),
     by=id,  
     .SDcols=c('A','B','C','D')]        # all columns

test
#    id    A   B    C D mean_test   sd_test
# 1:  1 2.00 3.0 4.00 5     3.500 1.2909944
# 2:  2 3.75 4.5 5.25 6     4.875 0.9682458
# 3:  3 5.50 6.0 6.50 7     6.250 0.6454972
# 4:  4 7.25 7.5 7.75 8     7.625 0.3227486
# 5:  5 9.00 9.0 9.00 9     9.000 0.0000000

# ---- repeat for a subset of columns
test[,`:=`(mean_test = rowMeans(.SD),   # mean over row
           sd_test =   sd(.SD)),        # standard dev over row
     by=id,                             # uniq key for row processing
     .SDcols=c('A','B')]   ## select the subset of columns


# ===============================================================================
