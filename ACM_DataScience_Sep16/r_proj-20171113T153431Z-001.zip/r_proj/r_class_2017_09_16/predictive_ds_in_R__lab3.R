# =====================================================================================================================
# file:         predictive_ds_w_R__lab2.R
# project:      Predict HoMe EQuity (HMEQ) loan default
# by:           Greg Makowski
# last update:  Wed, April 25, 2017
#
# Data: HMEQ - HoMe EQuity line of credit.  A line of credit loan, secured by a persons home.
# Using loan applicaiton, person and property data, predict which loans went delinquint (BAD=1) after a year.
#
#   rec_ID   record ID, key field for each loan application for  a line of credittr
#   BAD      After 1 year, loan went in default, (=1, 20%) vs. still being paid (=0) 
#   CLAGE    Credit Line Age, in months (for another credit line)
#   CLNO     Credit Line Number
#   DEBTINC  Debt to Income ratio
#   DELINQ   Number of delinquent credit lines
#   DEROG    Number of major derogatory reports
#   JOB      Job, 6 occupation categories
#   LOAN     Requested loan amount
#   MORTDUE  Amount due on existing mortgage
#   NINQ     Number of recent credit inquiries
#   REASON   “DebtCon“ = debt consolidation, “HomeImp“ = home improvement
#   VALUE    Value of current property 
#   YOJ      Years on present job
#
# =====================================================================================================================

# ---- one time install packages/libraries on disk
install.packages("e1071")
install.packages("gmodels")
install.packages("Hmisc")
install.packages("data.table")
install.packages("doMC")
install.packages("doParallel")
install.packages("caret")
install.packages("rpart")
install.packages("partykit")   # requires grid
install.packages("pROC")
install.packages("nnet")


# --------------------------------------------------
# ---- Load library program into RAM. List of all libraries used at any time in this training.
library(e1071)          # skewness(), wrapper for C++ libsvm with svm() and more
library(gmodels)        # CrossTable(), like SAS PROC FREQ  
library(Hmisc)          # for Exploratory Data Analysis.  describe(). cut2() for equal frequency binning
library(data.table)     # data.table(), fread()  are VASTLY better than data.frames for data storage & manipulation, fread()
library(utils)          # objectSize()

# ---- loaded later, but listed here to be sure they are installed
# library(doMC)           # Mac: foreach parallel for loop processing & other, from Revolution Analytics
# library(doParallel)     # Windows: foreach parallel processing instead of doMC() for Mac
# library(caret)          # Classification And REgression Training - wrapper over many predictive models
# library(rpart)          # recursive partitioning, CART decision tree predictive algorithm
# library(partykit)       # plot decision trees, other tree infrastruture, pruning of nodes
# library(pROC)           # tools for calc, vis or comparing Receiver Operating Characteristic (ROC curves)
# library(nnet)           # basic neural network library (not deep learning)

# library()               # list the library packages available to be  loaded in memory
sessionInfo()           # list attached packages, R version and other


# --------------------------------------------------
# ---- define input/output parameter list
param_io <- list()            # create a list variable
param_io$input_dir <-         "c:/Users/Greg Makowski/Documents/r_proj/r_class_2017_09_16/"
                # Mac example "/Users/gregmakowski/Desktop/r_class_2017_09_16/"
setwd( param_io$input_dir )   # set the working directory
param_io$input_data_file <-   paste0(param_io$input_dir, "hmeq.csv")
param_io$data_ver_stub <-     paste0(param_io$input_dir, "hmeq")

# ---- manipulate an example data structure
param_io                      # show the full list
length(param_io)              # find the length, use for list iteration
param_io$input_data_file      # access by list element name
param_io[3]                   # access by subscript
str(param_io)                 # get the structure of an object
print(param_io)               # print an object
class(param_io)               # find the type of an object
object_size(param_io)         # list the memory size of an object   # package utils

# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- Fast Read the data into a data table (from data.table library, reads million record tables in few sec)
dt <- fread(param_io$input_data_file)    # creats a data table  (much better than a data.frame.  Data Table is new in last few years)
ls()                          # list objects in memory. See also RStudio top right, Environment

? fread()   # to get read the help or documentation
# web search "r data.table fread tutorial example"   if you want more

sort( sapply(ls(),
             function(x) {object.size(get(x))} 
             ) )              # give a sorted list of objects in memory
# function(x)   is a generic function defined and used in the scope of another function

# in R, avoid for() loop on over 1k elements, use the vector apply() family
#   search "r tutorial apply" or go to   https://www.datacamp.com/community/tutorials/r-tutorial-apply-family
# sapply - apply vect function, read in list or vect, output vector
# lapply - apply vect function, read in list or vect, output list
#  apply - apply vect function, read in matrix, operate on "margin", i.e. dimension 1 or 2
# tapply - apply vect function, for data.frames


# ---- try the help tab on right, or ? ls() or web search for "r ls pdf"


# SKIP OR ADD LATER  fwrite(iris, "iris.csv")
# http://www2.warwick.ac.uk/fac/sci/moac/people/students/peter_cock/r/iris_plots


# ---- now you try str(), class()


# --------------------------------------------------
# ---- explore looking at the data set
# ---- find out about the file
dim(dt)     # 5960  14    get the dimensions, the number of rows and columns
dim(dt)[1]  # 5960
dim(dt)[2]  # 14
nrow(dt)    # 5960   # number of rows (or columns)
ncol(dt)    # 14     # used in for loops

names(dt) # get the field names

str(dt)   # structure of the data.  For each field, list field name, type and example values


# ---- starting EDA - Exploratory Data Analysis  (Univariate, not with respect to the target)
summary(dt)  # aggregate measures per field:  min, mean, max, NA' frequency
# note, DEBTINC has 1267 missing, 4693 not-missing.  May want to skip 

describe(dt) # info like summary(), but a more detailed.  Frequency of catgorical fields.  Part of Hmisc library.

sum(is.na(dt))              # how many missing values?  4740 (out of 5960 records!)

dt$na_cnt <- apply(dt, 1, function(x) sum(is.na(x)))  
sum(dt$na_cnt)    
sum(dt$na_cnt) / nrow(dt)   # 80% of the rows have at least one missing value
dt[, na_cnt:= NULL]         # delete the temporary col

table(dt$JOB)               # frequency table, for categorical values in a field
# try other freq tables on different fields




# --------------------------------------------------
# ---- DESIGN TO SCALE WITH COMPLEXITY 
#          HUGE NUMBER OF INPUT VARS, OR DYNAMICALLY CHANGING
#      Want to be robust to changes upstream in the preprocessing
#
#      work with "sets" of fields, select by naming convention or other metadata
#      The selection is robust to adding or dropping fields upstream
#      Also makes it easy to "drop" or "keep" sets of variables (set intersection)
#      This reduces "brittleness" of the current code

var_list <- names(dt)    # extract a list of all the possible input vars
var_list                 # show what was generated. 
var_list[3]

d_any_vars <-   var_list[ grepl("D",  var_list) ]     # match the var names with "D anywhere"
d_any_vars

d_start_vars <- var_list[ grepl("^D",  var_list) ]    # match the var names with "D in the start"
d_start_vars

JOB_vars <-     var_list[ grepl("JOB", var_list) ]    # match the var names with "JOB"
ts_vars <-      var_list[ grepl("timeseries_m[1234567]_", var_list) ]   # pull all of a time series
# yes, I know we don't have any time series vars.  We can be robust, and not worry

target_var <-   "LOAN"


param_model <- list()
param_model$input_vars <- sort( c( target_var, d_start_vars, ts_vars, "MORTDUE", "CLNO" ) )
param_model$input_vars



# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- START EDA & PREPROCESSING
param_prep <- list()
# param_prep$contin_to_n_bin <-    7    # used for creating equal frequency binning in initial preprocessing

# ---- set the parameters for EDA and preprocessing on data version d1
param_prep$target <-             "BAD"
param_prep$targ_is_catg <-       TRUE
param_prep$key <-                "rec_ID"
param_prep$data_ver <-           1         # first sprint, first data version
param_prep



# -------- missing value substitution
# ---- manual for 1 col          #t = temporary development line, investigation, not part of final function
sapply(dt, mean)                 #t for each var, returns NA for that var if ANY records are missing.
#t web search:  r mean     (want to read doc, find parameter to use only non-missing records)
#t web search:  r sapply mean na.rm=true
sapply(dt, mean, na.rm=TRUE)     #t skips NA records, and returns mean of rest.  But gives warnings on char cols (that is good)

options(warn=-1)                 #t web search:  R hide warnings.  Want code that gives no UNEXPECTED warnings when running in production
sapply(dt, mean, na.rm=TRUE)     #t hide the warning message.  Good if you want NO unknown warnings in production
options(warn=0)


# ----- what is the average bad rate?  Save as metadata
table(dt$BAD)                    #t frequency of all the categories in a field
table(dt$BAD)[2]                 #t get the 2nd element of the output table data structure
table(dt$BAD)[2] / nrow(dt)      #t convert to a % of total records, number of rows, in the table

param_prep$target_global_mean <- table(dt$BAD)[2] / nrow(dt)   # assign the global target to a list element


# --------------------------------------------------
# ---- EDA on bad rates by JOB (try and develop generic code for a function)

table(dt$JOB, dt$BAD)
job_t <- table(dt$JOB, dt$BAD)
str(job_t)
job_t[,1]

# ---- web search:  r table percent    (want more details in output.  Cell%, row%, col%)
library(gmodels)
CrossTable(dt$JOB, dt$BAD)    # like SAS proc FREQ 
job_ct <- CrossTable(dt$JOB, dt$BAD)    
str(job_ct)   # good, but maybe a bit complex to start with
names(job_ct)
job_ct$t
job_ct$t[1,]
job_ct$t[,1]     # same as job_t[,1],  can navigate data structures that build up in complexity


# -----------------------------------------------------
# ---- consider building our own analysis, our own data structure, with a funciton
#      first explore and figure out what we want to do
#      save to a data structure which we build up
t_c <- table(dt$JOB)     # table on a categorical var
t_c                      # look at what is created
str(t_c)                 # a table, not a data.table
class(t_c)
dt_c <- as.data.table(t_c)
class(dt_c)              # confirm it worked
names(dt_c) <- c("catg_name", "catg_cnt")
dt_c                     # confirm changes
dt_c[, catg_perc := round( catg_cnt / sum(catg_cnt), 3) ]

t_2way <- table(dt$JOB, dt$BAD)
dt_2way <- as.data.table( cbind( t_2way[,1], t_2way[,2]) )
names(dt_2way) <- c( "targ_not", "targ")

dt_c <- cbind( dt_c, dt_2way)
# confirm
t_c
dt_2way
dt_c

dt_c[, perc_targ := round((targ/(catg_cnt)),2) ]
dt_c[, lift := round(perc_targ/0.2, 2)]
dt_c
setkey(dt_c,lift)   # order by the var lift
dt_c   # check
# OBSERVATION:  The lift is very different for missing, keep them sepearate

# -----------------------------------------------------------------------
# for writing and testing the function, define the parameter vars used inside
catg_var <- "JOB"
targ_var <- "BAD"
global_mean <- 0.2


# -----------------------------------------------------------------------
eda_targ_by_catg <- function( dt, catg_var, targ_var, global_mean ) {

  # ---- 1 way catg analysis, count and perc of categorical frequencies 
  t_c <-  table(dt[, catg_var, with=FALSE] )    # table on a categorical var
  dt_c <- as.data.table(t_c)
  names(dt_c) <- c("catg_name", "catg_cnt")
  dt_c[, catg_perc := round( catg_cnt / sum(catg_cnt), 3) ]
  
  # ---- 2 way (catg by target) frequency analysis
  #  t_2way <-  table( dt[, catg_var, with=FALSE], dt[, targ_var, with=FALSE] )
  t_2way <-  table( dt[, eval(parse(text=catg_var)) ], dt[, eval(parse(text=targ_var))] )
              # R macro, eval(parse(text=SOMEVAR)) will convert any text to code, before execution
  
  dt_2way <- as.data.table( cbind( t_2way[,1], t_2way[,2]) )
  names(dt_2way) <- c( "targ_not", "targ")
  
  # ---- combine the 1 and 2 way
  dt_c <- cbind( dt_c, dt_2way)
  
  # ---- calc lift, order by lift
  dt_c[, perc_targ := round((targ/(catg_cnt)),3) ]
  dt_c[, lift := round(perc_targ/eval(parse(text=global_mean)), 3)]
  setkey(dt_c,lift)   # order by the var lift
  
  return(dt_c)  
}

  
# -----------------------------------------------------------------------
depend_by_job <- eda_targ_by_catg( dt, "JOB", "BAD", param_prep$target_global_mean )  
depend_by_job
depend_by_job
# LESSON LEARNED --> treat the blank JOB as its own category, because the lift and avg target rate are so different

# ---- now call this for other categorical vars
#      while this has an ordered value, it is still helpful to look at this for EDA
depend_by_delinq <- eda_targ_by_catg( dt, "DELINQ", "BAD", param_prep$target_global_mean )  
depend_by_delinq

depend_by_reason <- eda_targ_by_catg( dt, "REASON", "BAD", param_prep$target_global_mean )  
depend_by_reason
# missing has same perc_targ as the most frequent category, DebtCon - so group them because of similarity

# ---- check other vars because it is easy now (but they have ordered values)
depend_by_clno <- eda_targ_by_catg( dt, "CLNO", "BAD", param_prep$target_global_mean )  
depend_by_clno
depend_by_clno[ 0.03 <= catg_perc, ]  # just look at the more frequent categories (more than x%)
    # may not be the best EDA for these vars
setkey(depend_by_clno, catg_name)     # because so many ordered categories, change back to that order
depend_by_clno[ 0.03 <= catg_perc, ]  # just look at the more frequent categories (more than x%)
    # does not look very predictive

depend_by_yoj <- eda_targ_by_catg( dt, "YOJ", "BAD", param_prep$target_global_mean )  
depend_by_yoj
depend_by_yoj[ 0.03 <= catg_perc, ]  # just look at the more frequent categories (more than x%)
    # may not be the best EDA for these vars
setkey(depend_by_yoj, catg_name)     # because so many ordered categories, change back to that order
depend_by_yoj[ 0.03 <= catg_perc, ]  # just look at the more frequent categories (more than x%)


# --------------------------------------------------
# ---- prep: deal with missing values for floats and categoricals
eda <- list()                    # create a list variable for Exploratory Data Analysis and metadata
options(warn=-1)
eda$means <- sapply(dt, mean, na.rm=TRUE)   # save to a data structure  (in production scoring, read from disk the means of training data)
options(warn=0)

eda$means[4]                     #t get data out of the data structure.  Nth position of the list
eda$means["MORTDUE"]             #t use the column name, to look up its mean

describe(dt$MORTDUE)
dt[ is.na(MORTDUE), MORTDUE := eda$means["MORTDUE"]]    # if (the record has a missing MORTDUE) then replace with mean
describe(dt$MORTDUE)             #t check this worked, the "missing" count is not 0

dt[ is.na(VALUE),   VALUE :=   eda$means["VALUE"]]    
dt[ is.na(YOJ),     YOJ :=     eda$means["YOJ"]]   
dt[ is.na(DEROG),   DEROG :=   as.integer(round(eda$means["DEROG"]))]      #t get warnings, column is INTEGER
dt[ is.na(DEROG),   DEROG :=   0]                       # replace with mode, the most frequent catgory
dt[ is.na(DELINQ),  DELINQ :=  0]                       # check for any other integer numerics

dt[ is.na(CLAGE),   CLAGE :=   eda$means["CLAGE"]]   
dt[ is.na(NINQ),    NINQ :=    0]   
dt[ is.na(CLNO),    CLNO :=    as.integer( round(eda$means["CLNO"])  ) ]      #t also integer, get warning.  Many vals, looked diff in describe()
table(dt$CLNO)                                          #t get a frequency count of all categories.   hard to read, so transpose with t()
t(table(dt$CLNO))                                       #t the mode is 21, with a count of 457
eda$means["CLNO"]                                       #t round(21.2961) is also 21!

dt[ is.na(CLNO),    CLNO :=    as.integer(round(eda$means["CLNO"]))]  # wow, mean == mode.  Use 21

dt[ is.na(DEBTINC), DEBTINC := eda$means["DEBTINC"]]   


# the above approach is okay for a handful of cols, but what if you need to SCALE IN COMPLEXITY
# to scale over an arbitrary number of fields?   Then use R Macros  
# ---- create a list of numeric columns, to apply mean substitution
num_mean_sub <- c("MORTDUE", "VALUE", "YOJ", "CLAGE", "DEBTINC")
for (c in 1:length(num_mean_sub)) {
  # ---- code_ln ends up like:    dt[ is.na(DEBTINC), DEBTINC := eda$means['DEBTINC']]
  code_ln <- paste0( "dt[ is.na(", num_mean_sub[c], "), ", num_mean_sub[c], " := eda$means['", num_mean_sub[c], "']]"  )
  eval(parse(text=code_ln))  # execute the macro text
}


# --------------------------------------------------
# ---- prep: deal with missing values for text categoricals
# ---- check categorical cols for missing.  Replace with most frequent (mode)  Job="Other".   REASON="DebtCon"
dt[ ""==JOB,    JOB :=    "missing"]   # different enough to be its own category
dt[ ""==REASON, REASON := "DebtCon"]   

describe(dt)                #t confirm there are no more missing values
sum(is.na(dt))              #t a sum of 0 indicates no more missing values


# --------------------------------------------------
# ---- prep:  1-of-N binary encode the categorical cols.  Validate, then drop chars.
# web search: r one of n encoding
# ~JOB is the variable to be encoded
# -1 supresses a new column of 1's, the intercept of the model
dt_job <- with(dt, data.table(model.matrix(~JOB-1, dt)) )
dt_res <- with(dt, data.table(model.matrix(~REASON-1, dt)) )

dt <- cbind(dt, dt_job, dt_res)    # column bind, append columns together
dt[1:10, ]                         #t validate things worked
dt[ , JOB := NULL]                 # delete the two encoded character columns
dt[ , REASON := NULL]


# --------------------------------------------------
# -------- general for all numeric
# ---- check skew and safelog()
eda$skew <- sapply(dt, skewness)  # create a list of skewness values for each column
eda$skew                          # look at the results
# VALUE, DEROG and DELINQ have values over 3.

dt[, value_lg :=  log(VALUE + 1)]  # +1 to avoid numeric error from log(0).   Sometimes also need log(abs(var)+1) & may want to put sign back on after
dt[, derog_lg :=  log(DEROG + 1)]
dt[, delinq_lg := log(DELINQ + 1)]
eda$skew <- sapply(dt, skewness)  # check the reduced skewness

dt[, derog_lg :=  log(derog_lg + 1)]   # reduced skew from 5.7 to 3.2.  Want to reduce below 3.
eda$skew <- sapply(dt, skewness)  # reduced to 2.7.  Good enough

#  dt[, VALUE := NULL]      # keep these to test the hypothosis that logs help
#  dt[, DEROG := NULL]      # may need to remove for regression, which is sensitive to correlating inputs
#  dt[, DELINQ := NULL]


# --------------------------------------------------
# ---- rescale input vars to a 0..1 range
eda$min <- sapply(dt, min) 
eda$max <- sapply(dt, max) 

for (c in 3:ncol(dt)) {   # start at 3, skipping the key and the target columns.  Don't change those.
  # code_ln example:  dt[, LOAN := (LOAN - eda$min[c])/(eda$max[c] - eda$min[c]) ]
  code_ln <- paste0( "dt[, ", names(dt)[c], " := (", names(dt)[c], " - eda$min[c])/(eda$max[c] - eda$min[c]) ]")
  eval(parse(text=code_ln))
}


# --------------------------------------------------
# ---- create a training weight, based on the target and the log of the value.  Must be integer, 1+
#      design:  if good loan, weight = 1
#               if bad loan, weight is higher as value increases.  values range from 1..10
# dt[, weight_val := ifelse(BAD==1,1,round(value_lg + 1)*5)]


# --------------------------------------------------
# ---- write out the data sets to save data ver.
#      Some days I am working on the prep part, and I save here as a check point
#      Other days, I don't want to rerun that work, and I just want to pick up and model forward
#      As iterate over sprints, I revist and improve prior work (hence the data version)
#      The best model, and data version, could be from loop 2 instead of loop 3
checkpoint_write_or_read = "w"    # "w" or "r"

if (checkpoint_write_or_read == "w") {
  fwrite(dt, file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
  
} else {
  # ---- just read this in if I have to start at a mid-point checkpoint
  dt <- fread( file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
}


# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------
# ---- MODEL BUILDING

# ------------------------------------------------------------
# ---- train in parallel using Multi Core (for Unix/Mac) or doParallel (for Win)
# To enable parallel processing, you first need to load an adaptor for the foreach package 
# (doMC, doMPI, doParallel, doRedis, doRNG or doSNOW)), register the backend, and set parallel=TRUE.

#### for today, avoid a small new bug in caret(), fixed with a github load (detailis below)
#### don't run doParallel() in the tutorial unless you Session --> Restart R & New Session before running caret()

# ---- if (WINDOWS)
# library(doParallel)        # for Windows      ? doParallel() for doc
# registerDoParallel(cores=4)

# ---- if (Mac / Unix)
# library(doMC)            # Unix/Mac: parallel for loop processing & other, from Revolution Analytics
# registerDoMC(cores = 4)  # for MacPro.  Watch CPU load with "activity monitor"

# optionally, see p3-4 of vignette to test   
# https://cran.r-project.org/web/packages/doParallel/vignettes/gettingstartedParallel.pdf


# ------------------------------------------------------------
# split into training vs val, 75% sample, use caret function createDataPartition()
library(caret)
set.seed(42)     # set seed so later runs return the same result, results are repeatable 

dt$BAD <- factor(dt$BAD,  levels = c(0, 1))   # R factor internally encodes text category as int
input_vars <- names(dt[, 2:ncol(dt)])  # skip the rec_ID var, keep just the target and inputs
input_vars          # to visually check the list

trn_row_num <- createDataPartition(dt$BAD,  p = 0.75,  list = FALSE)
head(trn_row_num)   # one column data.frame, col named Resample1 with row index of training records
dim(trn_row_num)    # 4471 1
d1_trn <- dt[ trn_row_num, input_vars, with=FALSE]
d1_val <- dt[-trn_row_num, input_vars, with=FALSE]
dim(d1_val)   # 1489 23

# if first time, and you have not created a "models" subdir in the working directiory
# shell("mkdir models")

saveRDS( d1_trn, "models/d1_trn.rds")  # save the data (with this trn/val split) for future use
saveRDS( d1_val, "models/d1_val.rds")  # save the data (with this trn/val split) for future use


# ------------------------------------------------------------
# ---- PLAN TO MANAGE COMPLEXITY (may want consistency in proj over team members, "vacation insurance")
# ---- Stay organized, develop some naming struture good enought to track 30-300 models
#      The alternative to a naming convention is very, very detailed developer docs - which takes longer.
#      Also, think about switching projects, coming back to refresh a model X months later, working tired..
#      * data versions (d1, d2,... later sprints)
#      * training vs. test data
#      * algorithm used to train,  model version (m1, m2, m3, ..)
#      * scored training/test data data, with model using alg X and m2
#      * design principal:  slowest changes to the farthest left of the name
#  
#   Left most name part changes least frequently.  Rightmost change the most, or most categories
#   d1_trn          data version 1, training input data
#   d1_val          data ver 1, test or valiation data
#   d1_hld          data ver 1, on another holdout data subset (if used)
#   d1_tree_m1      trained model, data ver = 1, alg = tree, tree model ver = 1
#   d1_treec_m3     (similar to above, the tree was trained with <c>aret, different code)
#   d1_trn_tree_m1  apply tree m1 to score the d1 training data
#   d1_val_tree_m1  apply tree m1 to score the d1 validation data
#
#   DATA NAMES      (grammar)
#   d<data_ver>_<trn|val|hld>  
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>    (if scored with a model)
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_class  produce a categorical forecast
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_prob   produce a probability forecast
#   d<data_ver>_<trn|val|hld>_<alg>_<alg ver>_roc    ROC score
#
#   MODEL NAMES
#   d<data_ver>_<alg>_<alg ver>
#   d<data_ver>_<alg>_<alg ver>_plot   (or other things with the model)
#   

# ------------------------------------------------------------
# ---- train some predictive models
library(rpart)          # recursive partitioning, CART decision tree predictive algorithm


d1_tree_m1 <- rpart(BAD ~ .,
                    data =    d1_trn,
                    control = rpart.control(maxdepth = 2))  # max of 2 splits, easy to plot
d1_tree_m1

# ---- try the partykit package for plotting trees
library(partykit)
d1_tree_m1_plot <- as.party(d1_tree_m1)
plot(d1_tree_m1_plot)                # nice looking plot

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
jpeg(filename= paste0(param_io$input_dir,"models/d1_tree_m1_plot.jpeg"), width = 1800, height = 900)   
plot(d1_tree_m1_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ------------------------------------------------------------
# ---- generate a larger tree, not limited to 2 levels.  
# use "One SE" rule
# estimate standard error for each tree size, then
# choose the simplest tree within one standard error of the absolute best tree size
d1_tree_m2 <- rpart(BAD ~ .,
                    data =    d1_trn,
                    control = rpart.control(minbucket = 20))

saveRDS( d1_tree_m2, "models/d1_tree_m2.rds")  # save the model for future scoring

d1_tree_m2_plot <- as.party(d1_tree_m2)
plot(d1_tree_m2_plot)                # nice looking plot

d1_tree_m2   # look at the text tree

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
#      this version is much higher resolution, and more readable
jpeg(filename= paste0(param_io$input_dir,"models/d1_tree_m2_plot.jpeg"), width = 1800, height = 900)   
plot(d1_tree_m2_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ------------------------------------------------------------
# ---- tree scoring of test data
d1_val_tree_m2 <- predict(d1_tree_m2, 
                          newdata = d1_val,
                          type =    "class")    # class = category,  prob = probability

confusionMatrix(data =      d1_val_tree_m2, 
                reference = d1_val$BAD)

# the confusion matrix assumes, give a 20% target rate, that deployment is at a 20% depth on lift chart
# what if the business cost and profit chooses a different boundary?
# that is the motivation for a lift chart, to show all the deployment boundaries
# Greg: I need to see if there are parameters to set in CF, or send a suggestion to Max Khun


d1_val_tree_m2_conf <- confusionMatrix(data =      d1_val_tree_m2, 
                                       reference = d1_val$BAD)
d1_val_tree_m2_conf

str( d1_val_tree_m2_conf)             # get the data structure for what was printed to the console
d1_val_tree_m2_conf$overall
d1_val_tree_m2_conf$overall$Accuracy  # no, not a named list (IGNORE THE ERROR MSG, CREATED TO TEACH)
d1_val_tree_m2_conf$overall[1]        # works to get the number for accuracy (save what you track/model)
    # CAUTION: "overall accuracy" assumes a 20% deployment boundary, business may be different


# ------------------------------------------------------------
# ---- create ROC curve 
#      CAUTION: Receiver Operator Characteristic (ROC) considers EQUALLY all deployment boundaries, 
#               not the one or two deployment boundaries you care about

d1_val_tree_m2_prob <- predict(d1_tree_m2, 
                               newdata = d1_val)

head(d1_val_tree_m2_prob, 3)
names(d1_val_tree_m2_prob)

library(pROC)
? pROC()          # read the doc for a libarary after you load it


#     The roc function assumes the *second* level is the one of
#     interest, so we use the 'levels' argument to change the order.
d1_val_tree_m2_roc <- roc(response = d1_val$BAD,
                          predictor = d1_val_tree_m2_prob[, 2], 
                          levels =    rev(levels(d1_val$BAD)))

#     Get the area under the ROC curve
auc(d1_val_tree_m2_roc)
# Area under the curve: 0.8577

plot(d1_val_tree_m2_roc)


# ------------------------------------------------------------
# ---- start using caret to train models.  
# save the trainControl settings to cv_ctrl, used later in the train() function
cv_ctrl <- trainControl(method = "repeatedcv",  # 10 fold cross validation
                        repeats = 5)            # repeated 5 times

# ---- I added "c" to the end of the tree in the model name
# detach(package:doParallel, unload=TRUE)
d1_treec_m3 <- train(BAD ~ .,
                     data =       d1_trn,
                     control =    rpart.control(minbucket = 20),
                     method =     "rpart",       # train a CART tree model, as before
                     tuneLength = 9,             # caret function to eval many models
                     trControl =  cv_ctrl)       # cross validation 5 times, used above params here
#### NEW ERROR HERE: unable to find variable "optimismBoot"
#### best fix, install caret from github, see  https://stackoverflow.com/questions/46244763/caret-train-function-unable-to-find-variable-optimismboot
#### easy fix in tutorial, don't load doParallel() or doMC()    (avoid walking students through github install)

saveRDS( d1_treec_m3, "models/d1_treec_m3.rds")  # save the model for future scoring

d1_treec_m3  # shows 9 values of cp tested 
# cp is the rpart complexity parameter to stop growing forward
# best was cp = 0.003923767   (default is 0.01)


str(d1_treec_m3)  # a very long list

d1_treec_m3$finalModel  # output the text tree
d1_treec_m3_plot <- as.party(d1_treec_m3$finalModel)
plot(d1_treec_m3_plot)                # nice looking plot

# note, JOBmissing came into the tree

# ---- to save the same plot to disk.  can also change jpeg quality percent, default is 75%
#      this version is much higher resolution, and more readable
jpeg(filename= paste0(param_io$input_dir,"models/d1_treec_m3_plot.jpeg"), width = 1800, height = 900)   
plot(d1_treec_m3_plot)                # nice looking plot
dev.off()   # finish writing to disk after a series of plotting commands


# ---------------------------
# ---- check the validation accuracy
d1_val_treec_m3_prob <- predict(d1_treec_m3$finalModel, 
                                newdata = d1_val)

d1_val_treec_m3_roc <- roc(response =  d1_val$BAD,
                           predictor = d1_val_treec_m3_prob[, 2], 
                           levels =    rev(levels(d1_val$BAD)))
auc(d1_val_treec_m3_roc)  # 0.8577


# ---------------------------
d1_val <- readRDS( "models/d1_val.rds")  # save the data (with this trn/val split) for future use
source(file = paste0( param_io$input_dir, "segmented_sensitivity_analysis.R")) 

# ---- rank the most important variables to the model 
### predict_func <-     "predict"                # may change function to custom for ensemble of models
### model_in <-         d1_treec_m3$finalModel
### dt_in <-            d1_val                   # validation data or subset (keep to 10k or less)
### input_var_list <-   names(d1_val)[2:ncol(d1_val)]   # skip the first var, the target
### forc_var_pos <-     2                        # forecast variable column position in scored output matrix
### sens_mult_factor <- 1.05                     # optional parameter, defaults to 1.05

### d1_treec_m3_descrip <- segm_sens_anal( predict_func, model_in, dt_in, input_var_list, forc_var_pos, sens_mult_factor ) 
# d1_val_treec_m3_prob <- predict(d1_treec_m3$finalModel, 
#                                 newdata = d1_val)


# ------------------------------------------------------------
# ---- neural net
library(nnet)           # basic neural network library (not deep learning)

# use the same cv_ctrl specified before
cv_ctrl <- trainControl(method = "repeatedcv",  # 10 fold cross validation
                        repeats = 5)            # repeated 5 times   (can set SMALLER for FASTER)

###### Warning - most compute intensive part of class, may take 13 min to execute.  
#      Could submit before coffee/lecture/bathroom

# ---- training the many neural nets with all this cross validation & retraining takes longer
#      about 13 minutes
#      track the time and go get your coffee
start_time_n <- proc.time()

d1_nnetc_m1 <-  train(BAD ~ .,
                      data =       d1_trn,
                      method =     "nnet",        # train a neural net model
                      tuneLength = 9,             # caret function to eval many models
                      trControl =  cv_ctrl)       # cross validation 5 times, used above params here

end_time_n <- proc.time()
duration_n <- end_time_n - start_time_n
duration_n

length(duration_n)
names(duration_n)
duration_n[3]       # 807.683
duration_n[3]/60    # 13 min

saveRDS( d1_nnetc_m1, "models/d1_nnetc_m1.rds")  # save the model for future scoring


#  weights:  358
#  initial  value 6223.589862 
#  iter  10 value 2209.654782
#  iter  20 value 2112.410853
#  iter  30 value 2062.964599
#  iter  40 value 2015.094375
#  iter  50 value 1851.424283
#  iter  60 value 1716.623851
#  iter  70 value 1638.157046
#  iter  80 value 1579.116674
#  iter  90 value 1563.965881
#  iter 100 value 1550.663330
#  final  value 1550.663330 
#  stopped after 100 iterations


d1_nnetc_m1$finalModel
# ---- results
#      a 22-15-1 network with 361 weights
#      inputs: LOAN MORTDUE VALUE YOJ DEROG DELINQ CLAGE NINQ CLNO DEBTINC JOBMgr JOBmissing JOBOffice JOBOther JOBProfExe JOBSales JOBSelf REASONDebtCon REASONHomeImp value_lg derog_lg delinq_lg 
#      output(s): .outcome 
#      options were - entropy fitting  decay=0.005179475


# ---- now I will take those settings and change one parameter
#      I want to test connecting the input layer to the output, skipping the hidden
#      This solves the linear part of the problem quicker with the skip layer
#      and leaves the hidden nodes to solve the remaining challenges
d1_nnet_m2_time_start <- proc.time()
d1_nnet_m2 <- nnet(d1_trn[, LOAN:delinq_lg ],
                   as.integer(d1_trn$BAD)-1,  # not the formula, but inputs & target
                   size =    17,          # number hidden nodes
                   entropy = TRUE,        # caret found setting 1
                   decay =   0.005179475, # caret found setting 2
                   skip =    TRUE         # new change, parameter to test
                  )
d1_nnet_m2_time_end <- proc.time()
d1_nnet_m2_time_dur <- d1_nnet_m2_time_end - d1_nnet_m2_time_start
d1_nnet_m2_time_dur[3]/60  # elapsed 2% of a minute

saveRDS( d1_nnet_m2, "models/d1_nnet_m2.rds")  # save the model for future scoring

# final val 1129  
1173 - 1129   # 44 better


# ------------------------------------
# ---- now increase the iterations significantly 
d1_nnet_m3 <- nnet(d1_trn[, LOAN:delinq_lg ],
                   as.integer(d1_trn$BAD)-1,  # not the formula, but inputs & target
                   size =    17,          # number hidden nodes
                   entropy = TRUE,        # caret found setting 1
                   decay =   0.005179475, # caret found setting 2
                   skip =    TRUE,
                   maxit =   1000         # new change, parameter to test
)

# final val 781, after 860 iterations  (leveled off to the same value at 680, don't expect more improvement from this param)
1173 - 781   # 392 better, after using caret with my own improvements

saveRDS( d1_nnet_m3, "models/d1_nnet_m3.rds")  # save the model for future scoring



# ------------------------------------------------------------
# ---- XGboost
library(xgboost)

# ---- caret and other libraries expected a binary target to be of type factor
#      a factor encodes numeric or character category values internally as 1, 2, 3..

# ---- xgboost works with specific data structures for its library
#      it expects all integer or numeric, no factors
#      Below are a few lines that explore to figure out, and then transform to the desired label
table(d1_trn$BAD)
table( as.integer(d1_trn$BAD) )
table( as.integer(d1_trn$BAD) -1 )

d1_trn_xgb_targ <- as.integer(d1_trn$BAD) - 1
d1_val_xgb_targ <- as.integer(d1_val$BAD) - 1


# ---- for xgboost, for the input data, we need a version without the key field or target
#      data tables by default do all in-place changes (by reference).  Need to be explicit to make a copy
d1_trn_xgb_inp <- copy(d1_trn)  # so we can modify x and not change train_data
d1_trn_xgb_inp[ , rec_ID := NULL]   # delete the key
d1_trn_xgb_inp[ , BAD := NULL]      # delete the target
d1_trn_xgb_inp <- as.matrix(d1_trn_xgb_inp)  # convert to a matrix

d1_val_xgb_inp <- copy(d1_val)  # so we can modify x and not change train_data
d1_val_xgb_inp[ , rec_ID := NULL]   # delete the key
d1_val_xgb_inp[ , BAD := NULL]      # delete the target
d1_val_xgb_inp <- as.matrix(d1_val_xgb_inp)  # convert to a matrix


# ---- convert to the optimized for xgboost data structure, DMatrix
d1_trn_xgb <- xgb.DMatrix(data =  d1_trn_xgb_inp,
                          label = d1_trn_xgb_targ)

d1_val_xgb <- xgb.DMatrix(data =  d1_val_xgb_inp,
                          label = d1_val_xgb_targ)


# ---- now train
d1_xgb_m1 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2,           # depth per tree
                     eta =       1,           # decay weight (high here because short nrounds)
                     nrounds =   2,           # train 2 small CART trees
                     objective = "binary:logistic")
#  [1]	train-error:0.181391   # results for tree 1
#  [2]	train-error:0.138671   # results for tree 1 + tree 2


# ---- now score or apply the model to forecast
d1_trn_xgb_m1 <- predict(d1_xgb_m1, d1_trn_xgb)
d1_val_xgb_m1 <- predict(d1_xgb_m1, d1_val_xgb)



# ---- now try (a more normal), longer sequence of 200
d1_xgb_m2 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2, 
                     eta =       0.25,        # smaller decay wgt
                     nrounds =   200,         # 200 small trees
                     objective = "binary:logistic",
                     subsample = 0.5 )        # random samp 50% train for each tree, helps with robustness
#  :
#  [195]	train-error:0.065086 
#  [196]	train-error:0.065310 
#  [197]	train-error:0.065310 
#  [198]	train-error:0.065310 
#  [199]	train-error:0.065310 
#  [200]	train-error:0.064191 

#  error dropped from 0.138 to 0.064,  much better

# ---- apply model
d1_trn_xgb_m2 <- predict(d1_xgb_m2, d1_trn_xgb)
d1_val_xgb_m2 <- predict(d1_xgb_m2, d1_val_xgb)



# ---- now try (a more normal), longer sequence of 1000!
d1_xgb_m3 <- xgboost(data =      d1_trn_xgb,  
                     max_depth = 2, 
                     eta =       0.25,        # smaller decay wgt
                     nrounds =   1000,        # 1,000 small trees
                     objective = "binary:logistic",
                     subsample = 0.5 )        # random samp 50% train for each tree, helps with robustness
#  :
#  [1000]	train-error:0.012972 

#  error continues to drop!!  .14 --> 0.06 --> .01 !!

saveRDS( d1_xgb_m3, "models/d1_xgb_m3.rds")  # save the model for future scoring


# ---- apply model
d1_trn_xgb_m3 <- predict(d1_xgb_m3, d1_trn_xgb)
d1_val_xgb_m3 <- predict(d1_xgb_m3, d1_val_xgb)


# =====================================================================================================================

