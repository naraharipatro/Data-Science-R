## install.packages("sparklyr")
## install.packages("openxlsx")
## install.packages("dplyr")
## install.packages("DBI")

library(sparklyr)
library(dplyr)
library(DBI)
library(openxlsx)
## spark_install()
setwd(change it to the path on your computer where you saved Sample - Superstore.xlsx)
quit("Not running all programs")

### Data preparation
dflocal =  openxlsx::read.xlsx("Sample - Superstore.xlsx", sheet = "Orders")



# Connect 
s_con <- spark_connect(master = "local")

### 3. Basic
print( Sys.time())
df_tbl <- copy_to(dest=s_con,dflocal) # slow and returns tibble()
print( Sys.time())

src_tbls(s_con)

df_tbl = tbl(s_con,'dflocal')

object.size(df_tbl)
object.size(dflocal)

print(df_tbl, n=5, width=Inf)

str(df_tbl) ## Spark connection details
glimpse(df_tbl) ## equivalent to str on data.frame


### 4. Using Dplyr
df_tbl %>% dplyr::select(Order_Date,Customer_ID,Customer_Name)
df_tbl %>% filter(Customer_ID == 'CG-2520', Ship_Mode == 'Same Day')
compute_results <- df_tbl %>% group_by(Customer_ID) %>% summarise(Sales = sum(Sales))
class(compute_results)

starttime = as.numeric(Sys.time())*1000
compute_results = df_tbl %>% group_by(Customer_ID) %>% summarise(Sales = sum(Sales))
endtime = as.numeric(Sys.time())*1000
print(endtime - starttime, digits = 15)

starttime = as.numeric(Sys.time())*1000
compute_results = dflocal %>% group_by(Customer.ID) %>% summarise(Sales = sum(Sales))
endtime = as.numeric(Sys.time())*1000
print(endtime - starttime, digits = 15)



### 5. Back to R from Spark
backtoR <- compute_results %>% collect()
class(backtoR)
src_tbls(s_con)
# this can be expensive if you 100s of data manipulations 
computed <- df_tbl %>% group_by(Customer_ID) %>% summarise(Sales = sum(Sales)) %>% compute("computedResults")
src_tbls(s_con)

# Sending SQL queries
query = "Select * from computedresults where   Customer_ID like '%85'"
(results <- dbGetQuery(s_con, query))

# Disconnect
spark_disconnect(sc = s_con)
