# =====================================================================================================================
# file:         pred_ds_w_R__lab3.R
# project:      Predictive Data Science in R 
#               https://www.meetup.com/SF-Bay-ACM/events/240173466/ 
# lab descrip:  Preprocess HoMe EQuity (HMEQ) loan default
# by:           Greg Makowski
# last update:  Sat 9/16/2017
#
# Data: HMEQ - HoMe EQuity line of credit.  A line of credit loan, secured by a persons home.
# Using loan applicaiton, person and property data, predict which loans went delinquint (BAD=1) after a year.
#
#   rec_ID   record ID, key field for each loan application for  a line of credittr
#   BAD      After 1 year, loan went in default, (=1, 20%) vs. still being paid (=0) 
#   CLAGE    Credit Line Age, in months (for another credit line)
#   CLNO     Credit Line Number
#   DEBTINC  Debt to Income ratio
#   DELINQ   Number of delinquent credit lines
#   DEROG    Number of major derogatory reports
#   JOB      Job, 6 occupation categories
#   LOAN     Requested loan amount
#   MORTDUE  Amount due on existing mortgage
#   NINQ     Number of recent credit inquiries
#   REASON   “DebtCon“ = debt consolidation, “HomeImp“ = home improvement
#   VALUE    Value of current property 
#   YOJ      Years on present job
#
# =====================================================================================================================

 
# --------------------------------------------------
# ---- define input/output parameter list
param_io <- list()            # create a list variable
param_io$input_dir <-         "C:/Users/Greg Makowski/Documents/r_proj/r_class_2017_09_16/"
setwd( param_io$input_dir )   # set the working directory
param_io$input_data_file <-   paste0(param_io$input_dir, "hmeq.csv")
param_io$data_ver_stub <-     paste0(param_io$input_dir, "hmeq")

dt <- fread(param_io$input_data_file)    


# ----------------------------------------------------------------------------------------------------------
# --------------------------------------------------
# ---- START EDA & PREPROCESSING
param_prep <- list()
# param_prep$contin_to_n_bin <-    7    # used for creating equal frequency binning in initial preprocessing

# ---- set the parameters for EDA and preprocessing on data version d1
param_prep$target <-             "BAD"
param_prep$targ_is_catg <-       TRUE
param_prep$key <-                "rec_ID"
param_prep$data_ver <-           1         # first sprint, first data version




# -------- missing value substitution
# ---- manual for 1 col          #t = temporary development line, investigation, not part of final function
sapply(dt, mean)                 #t returns NA if ANY records are missing.
#t web search:  r mean     (want to read doc, find parameter to use only non-missing records)
#t web search:  r sapply mean na.rm=true
sapply(dt, mean, na.rm=TRUE)     #t skips NA records, and returns mean of rest.  But gives warnings on char cols

options(warn=-1)                 #t web search:  r hide warnings
sapply(dt, mean, na.rm=TRUE)     #t hide the warning message.  Good if you want NO unknown warnings in production
options(warn=0)


# ----- what is the average bad rate?  Save as metadata
table(dt$BAD)                    #t frequency of all the categories in a field
table(dt$BAD)[2]                 #t get the 2nd element of the output data structure
table(dt$BAD)[2] / nrow(dt)      #t convert to a % of total records, number of rows, in the table

param_prep$target_global_mean <- table(dt$BAD)[2] / nrow(dt)   # assign the global target to a list element


# --------------------------------------------------
# ---- prep: deal with missing values for floats and categoricals
eda <- list()                    # create a list variable for Exploratory Data Analysis and metadata
options(warn=-1)
eda$means <- sapply(dt, mean, na.rm=TRUE)   # save to a data structure  (in production scoring, read from disk the means of training data)
options(warn=0)

eda$means[5]                     #t get data out of the data structure.  Nth position of the list
eda$means["MORTDUE"]             #t use the column name, to look up its mean

dt[ is.na(MORTDUE), MORTDUE := eda$means["MORTDUE"]]    # if (the record has a missing MORTDUE) then replace with mean
describe(dt$MORTDUE)             #t check this worked

dt[ is.na(VALUE),   VALUE :=   eda$means["VALUE"]]    
dt[ is.na(YOJ),     YOJ :=     eda$means["YOJ"]]   
dt[ is.na(DEROG),   DEROG :=   as.integer(round(eda$means["DEROG"]))]      #t get warnings, column is INTEGER
dt[ is.na(DEROG),   DEROG :=   0]                       # replace with mode, the most frequent catgory
dt[ is.na(DELINQ),  DELINQ :=  0]                       # check for any other integer numerics

dt[ is.na(CLAGE),   CLAGE :=   eda$means["CLAGE"]]   
dt[ is.na(NINQ),    NINQ :=    0]   
dt[ is.na(CLNO),    CLNO :=    as.integer( round(eda$means["CLNO"])  ) ]      #t also integer, get warning.  Many vals, looked diff in describe()
table(dt$CLNO)                                          #t get a frequency count of all categories.   hard to read, so transpose with t()
t(table(dt$CLNO))                                       #t the mode is 21, with a count of 457
eda$means["CLNO"]                                       #t round(21.2961) is also 21!

dt[ is.na(CLNO),    CLNO :=    as.integer(round(eda$means["CLNO"]))]  # wow, mean == mode.  Use 21

dt[ is.na(DEBTINC), DEBTINC := eda$means["DEBTINC"]]   


# the above approach is okay for a handful of cols, but what if you need to SCALE IN COMPLEXITY
# to scale over an arbitrary number of fields?   Then use R Macros  
# ---- create a list of numeric columns, to apply mean substitution
num_mean_sub <- c("MORTDUE", "VALUE", "YOJ", "CLAGE", "DEBTINC")
for (c in 1:length(num_mean_sub)) {
  # ---- code_ln ends up like:    dt[ is.na(DEBTINC), DEBTINC := eda$means['DEBTINC']]
  code_ln <- paste0( "dt[ is.na(", num_mean_sub[c], "), ", num_mean_sub[c], " := eda$means['", num_mean_sub[c], "']]"  )
  eval(parse(text=code_ln))  # execute the macro text
}




# --------------------------------------------------
# ---- prep: deal with missing values for text categoricals
# ---- check categorical cols for missing.  Replace with most frequent (mode)  Job="Other".   REASON="DebtCon"
table(dt$JOB)                #t find which category is the most frequent.  Think, is that reasonable to substitute?
table(dt$REASON)

dt[ ""==JOB,    JOB :=    "Other"]   
dt[ ""==REASON, REASON := "DebtCon"]   

describe(dt)                #t confirm there are no more missing values
sum(is.na(dt))              #t a sum of 0 indicates no more missing values


# --------------------------------------------------
# ---- prep:  1-of-N binary encode the categorical cols.  Validate, then drop chars.
# web search: r one of n encoding
# ~JOB is the variable to be encoded
# -1 supresses a new column of 1's, the intercept of the model
dt_job <- with(dt, data.table(model.matrix(~JOB-1, dt)) )
dt_res <- with(dt, data.table(model.matrix(~REASON-1, dt)) )

dt <- cbind(dt, dt_job, dt_res)    # column bind, append columns together
dt[1:10, ]                         #t validate things worked
dt[ , JOB := NULL]                 # delete the two encoded character columns
dt[ , REASON := NULL]


# --------------------------------------------------
# -------- general for all numeric
# ---- check skew and safelog()
eda$skew <- sapply(dt, skewness)  # create a list of skewness values for each column
# VALUE, DEROG and DELINQ have values over 3.

dt[, value_lg :=  log(VALUE + 1)]
dt[, derog_lg :=  log(DEROG + 1)]
dt[, delinq_lg := log(DELINQ + 1)]
eda$skew <- sapply(dt, skewness)  # check the reduced skewness

dt[, derog_lg :=  log(derog_lg + 1)]   # reduced skew from 5.7 to 3.2.  Want to reduce below 3.
eda$skew <- sapply(dt, skewness)  # reduced to 2.7.  Good enough

dt[, VALUE := NULL]      # remove the raw variables
dt[, DEROG := NULL]
dt[, DELINQ := NULL]


# --------------------------------------------------
# ---- rescale input vars to a 0..1 range
eda$min <- sapply(dt, min) 
eda$max <- sapply(dt, max) 

for (c in 3:ncol(dt)) {   # start at 3, to skip the key and the target columns.  Don't change those.
  # code_ln example:  dt[, LOAN := (LOAN - eda$min[c])/(eda$max[c] - eda$min[c]) ]
  code_ln <- paste0( "dt[, ", names(dt)[c], " := (", names(dt)[c], " - eda$min[c])/(eda$max[c] - eda$min[c]) ]")
  eval(parse(text=code_ln))
}





# ---------------------------------------------------------------------------------------------------------------------
eda_targ_by_catg <- function( dt, catg_var, targ_var, global_mean ) {
  
  # ---- 1 way catg analysis, count and perc of categorical frequencies 
  t_c <-  table(dt[, catg_var, with=FALSE] )    # table on a categorical var
  dt_c <- as.data.table(t_c)
  names(dt_c) <- c("catg_name", "catg_cnt")
  dt_c[, catg_perc := round( catg_cnt / sum(catg_cnt), 3) ]
  
  # ---- 2 way (catg by target) frequency analysis
  #  t_2way <-  table( dt[, catg_var, with=FALSE], dt[, targ_var, with=FALSE] )
  t_2way <-  table( dt[, eval(parse(text=catg_var)) ], dt[, eval(parse(text=targ_var))] )
  # R macro, eval(parse(text=SOMEVAR)) will convert any text to code, before execution
  
  dt_2way <- as.data.table( cbind( t_2way[,1], t_2way[,2]) )
  names(dt_2way) <- c( "targ_not", "targ")
  
  # ---- combine the 1 and 2 way
  dt_c <- cbind( dt_c, dt_2way)
  
  # ---- calc lift, order by lift
  dt_c[, perc_targ := round((targ/(catg_cnt)),3) ]
  dt_c[, lift := round(perc_targ/eval(parse(text=global_mean)), 3)]
  setkey(dt_c,lift)   # order by the var lift
  
  return(dt_c)  
}



# ----------------------------------------------------------------------------------------------------------
# set up parameters to call one EDA function
param_prep <- list()

# ---- set the parameters for EDA and preprocessing on data version d1
param_prep$target <-             "BAD"
param_prep$targ_is_catg <-       TRUE
param_prep$key <-                "rec_ID"
param_prep$data_ver <-           1         # first sprint, first data version
param_prep$target_global_mean <- table(dt$BAD)[2] / nrow(dt)   # assign the global target to a list element


# -----------------------------------------------------------------------
# ---- EXPLORATORY DATA ANALYSIS (EDA)
depend_by_job <- eda_targ_by_catg( dt, "JOB", "BAD", param_prep$target_global_mean )  
# LESSON LEARNED --> treat the blank JOB as its own category, because the lift and avg target rate are so different

# ---- now call this for other categorical vars
#      while this has an ordered value, it is still helpful to look at this for EDA
depend_by_delinq <- eda_targ_by_catg( dt, "DELINQ", "BAD", param_prep$target_global_mean )  

depend_by_reason <- eda_targ_by_catg( dt, "REASON", "BAD", param_prep$target_global_mean )  
# missing has same perc_targ as the most frequent category, DebtCon - so group them because of similarity





# --------------------------------------------------
# ---- write out the data sets to save data ver.
#      Some days I am working on the prep part, and I save here as a check point
#      Other days, I don't want to rerun that work, and I just want to pick up and model forward
#      As iterate over sprints, I revist and improve prior work (hence the data version)
#      The best model, and data version, could be from loop 2 instead of loop 3
checkpoint_write_or_read = "w"    # "w" or "r"

if (checkpoint_write_or_read == "w") {
  fwrite(dt, file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
  
} else {
  # ---- just read this in if I have to start at a mid-point checkpoint
  dt <- fread( file = paste0( param_io$data_ver_stub, "_d", param_prep$data_ver, ".csv" ))
}


# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------
# ---- MODEL BUILDING (next)

# =====================================================================================================================

